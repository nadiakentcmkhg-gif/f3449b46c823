# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(verglas src/verglas.cpp)
set_property(TARGET verglas PROPERTY CXX_STANDARD 11)
target_link_libraries(verglas lionss pthread)

add_executable(savegame-migrate src/savegame-migrate.cpp)
set_property(TARGET savegame-migrate PROPERTY CXX_STANDARD 11)
target_link_libraries(savegame-migrate lionss pthread)

add_executable(rnaFold src/rnaFold.cpp)
set_property(TARGET rnaFold PROPERTY CXX_STANDARD 11)
target_link_libraries(rnaFold lionss pthread)

add_executable(borg_compact src/borg_compact.cpp)
set_property(TARGET borg_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(borg_compact lionss pthread)

add_executable(loopUnroll8 src/loopUnroll8.cpp)
set_property(TARGET loopUnroll8 PROPERTY CXX_STANDARD 11)
target_link_libraries(loopUnroll8 lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(webpackCacheBust src/webpackCacheBust.cpp)
set_property(TARGET webpackCacheBust PROPERTY CXX_STANDARD 11)
target_link_libraries(webpackCacheBust lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(bwa-align src/bwa-align.cpp)
set_property(TARGET bwa-align PROPERTY CXX_STANDARD 11)
target_link_libraries(bwa-align lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(dither-floyd src/dither-floyd.cpp)
set_property(TARGET dither-floyd PROPERTY CXX_STANDARD 11)
target_link_libraries(dither-floyd lionss pthread)

add_executable(zfs_scrub src/zfs_scrub.cpp)
set_property(TARGET zfs_scrub PROPERTY CXX_STANDARD 11)
target_link_libraries(zfs_scrub lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(malachite src/malachite.cpp)
set_property(TARGET malachite PROPERTY CXX_STANDARD 11)
target_link_libraries(malachite lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(h2-hpack src/h2-hpack.cpp)
set_property(TARGET h2-hpack PROPERTY CXX_STANDARD 11)
target_link_libraries(h2-hpack lionss pthread)

add_executable(canbus_filter src/canbus_filter.cpp)
set_property(TARGET canbus_filter PROPERTY CXX_STANDARD 11)
target_link_libraries(canbus_filter lionss pthread)

add_executable(ssao_kernel src/ssao_kernel.cpp)
set_property(TARGET ssao_kernel PROPERTY CXX_STANDARD 11)
target_link_libraries(ssao_kernel lionss pthread)

add_executable(terraform-plan-prod src/terraform-plan-prod.cpp)
set_property(TARGET terraform-plan-prod PROPERTY CXX_STANDARD 11)
target_link_libraries(terraform-plan-prod lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(shader-hotreload src/shader-hotreload.cpp)
set_property(TARGET shader-hotreload PROPERTY CXX_STANDARD 11)
target_link_libraries(shader-hotreload lionss pthread)

add_executable(SilverBirch src/SilverBirch.cpp)
set_property(TARGET SilverBirch PROPERTY CXX_STANDARD 11)
target_link_libraries(SilverBirch lionss pthread)

add_executable(nvimLsp src/nvimLsp.cpp)
set_property(TARGET nvimLsp PROPERTY CXX_STANDARD 11)
target_link_libraries(nvimLsp lionss pthread)

add_executable(mermaid_render src/mermaid_render.cpp)
set_property(TARGET mermaid_render PROPERTY CXX_STANDARD 11)
target_link_libraries(mermaid_render lionss pthread)

add_executable(voxel-remesh src/voxel-remesh.cpp)
set_property(TARGET voxel-remesh PROPERTY CXX_STANDARD 11)
target_link_libraries(voxel-remesh lionss pthread)

add_executable(jasperware src/jasperware.cpp)
set_property(TARGET jasperware PROPERTY CXX_STANDARD 11)
target_link_libraries(jasperware lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(nightjar src/nightjar.cpp)
set_property(TARGET nightjar PROPERTY CXX_STANDARD 11)
target_link_libraries(nightjar lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

