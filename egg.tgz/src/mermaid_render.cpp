// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render mermaid graph\n", stdout);
  return lionss_run_workload("mermaid_render");
}
