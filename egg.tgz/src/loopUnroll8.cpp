// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Unroll by 8"); }
int main(){
  announce();
  return lionss_run_workload("loopUnroll8");
}
