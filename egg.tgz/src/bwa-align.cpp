// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Align short reads\n", stdout);
  return lionss_run_workload("bwa-align");
}
